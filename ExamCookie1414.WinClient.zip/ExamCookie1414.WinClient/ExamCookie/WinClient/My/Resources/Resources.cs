﻿// Decompiled with JetBrains decompiler
// Type: ExamCookie.WinClient.My.Resources.Resources
// Assembly: ExamCookie.WinClient, Version=1.4.1.4, Culture=neutral, PublicKeyToken=null
// MVID: E12BE1F8-B6E0-4BF5-B308-166F0E938C4B
// Assembly location: C:\Users\oskar\Downloads\ExamCookie1414.WinClient.exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ExamCookie.WinClient.My.Resources
{
  [StandardModule]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  [HideModuleName]
  internal sealed class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) ExamCookie.WinClient.My.Resources.Resources.resourceMan, (object) null))
          ExamCookie.WinClient.My.Resources.Resources.resourceMan = new ResourceManager("ExamCookie.WinClient.Resources", typeof (ExamCookie.WinClient.My.Resources.Resources).Assembly);
        return ExamCookie.WinClient.My.Resources.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => ExamCookie.WinClient.My.Resources.Resources.resourceCulture;
      set => ExamCookie.WinClient.My.Resources.Resources.resourceCulture = value;
    }

    internal static byte[] arm64_WebView2Loader
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (arm64_WebView2Loader), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ec_blue
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ec_blue), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ec_green
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ec_green), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ec_logo
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ec_logo), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ec_red
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ec_red), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap ec_yellow
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ec_yellow), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] ExamCookie_Library
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ExamCookie_Library), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] ManagedWifi
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (ManagedWifi), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MicrosoftEdgeWebview2Setup
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (MicrosoftEdgeWebview2Setup), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] VmDetect
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (VmDetect), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static string WCF_ENDPOINT
    {
      get => ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetString(nameof (WCF_ENDPOINT), ExamCookie.WinClient.My.Resources.Resources.resourceCulture);
    }

    internal static string WCF_PASSWORD
    {
      get => ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetString(nameof (WCF_PASSWORD), ExamCookie.WinClient.My.Resources.Resources.resourceCulture);
    }

    internal static string WCF_USERNAME
    {
      get => ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetString(nameof (WCF_USERNAME), ExamCookie.WinClient.My.Resources.Resources.resourceCulture);
    }

    internal static byte[] x64_WebView2Loader
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (x64_WebView2Loader), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] x86_WebView2Loader
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(ExamCookie.WinClient.My.Resources.Resources.ResourceManager.GetObject(nameof (x86_WebView2Loader), ExamCookie.WinClient.My.Resources.Resources.resourceCulture));
      }
    }
  }
}
