﻿// Decompiled with JetBrains decompiler
// Type: ExamCookie.Library.eBrowserType
// Assembly: ExamCookie.WinClient, Version=1.4.1.4, Culture=neutral, PublicKeyToken=null
// MVID: E12BE1F8-B6E0-4BF5-B308-166F0E938C4B
// Assembly location: C:\Users\oskar\Downloads\ExamCookie1414.WinClient.exe

#nullable disable
namespace ExamCookie.Library
{
  public enum eBrowserType
  {
    SAFARI = 1,
    CHROME = 2,
    FIREFOX = 4,
    INTERNET_EXPLORER = 8,
    MS_EDGE = 16, // 0x00000010
    OPERA = 32, // 0x00000020
    BRAVE = 64, // 0x00000040
    CLIQZ = 128, // 0x00000080
  }
}
