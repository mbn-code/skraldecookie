﻿// Decompiled with JetBrains decompiler
// Type: ExamCookie.Library.My.MyComputer
// Assembly: ExamCookie.WinClient, Version=1.4.1.4, Culture=neutral, PublicKeyToken=null
// MVID: E12BE1F8-B6E0-4BF5-B308-166F0E938C4B
// Assembly location: C:\Users\oskar\Downloads\ExamCookie1414.WinClient.exe

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

#nullable disable
namespace ExamCookie.Library.My
{
  [GeneratedCode("MyTemplate", "11.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  internal class MyComputer : Computer
  {
    [DebuggerHidden]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public MyComputer()
    {
    }
  }
}
