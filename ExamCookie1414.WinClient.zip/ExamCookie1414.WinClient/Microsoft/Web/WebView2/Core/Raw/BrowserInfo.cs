﻿// Decompiled with JetBrains decompiler
// Type: Microsoft.Web.WebView2.Core.Raw.BrowserInfo
// Assembly: ExamCookie.WinClient, Version=1.4.1.4, Culture=neutral, PublicKeyToken=null
// MVID: E12BE1F8-B6E0-4BF5-B308-166F0E938C4B
// Assembly location: C:\Users\oskar\Downloads\ExamCookie1414.WinClient.exe

#nullable disable
namespace Microsoft.Web.WebView2.Core.Raw
{
  internal static class BrowserInfo
  {
    public static string PRODUCT_VERSION = "119.0.2151.40";
  }
}
