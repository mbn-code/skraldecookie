﻿// Decompiled with JetBrains decompiler
// Type: Microsoft.Web.WebView2.Core.CoreWebView2MouseEventKind
// Assembly: ExamCookie.WinClient, Version=1.4.1.4, Culture=neutral, PublicKeyToken=null
// MVID: E12BE1F8-B6E0-4BF5-B308-166F0E938C4B
// Assembly location: C:\Users\oskar\Downloads\ExamCookie1414.WinClient.exe

using System.Runtime.InteropServices;

#nullable disable
namespace Microsoft.Web.WebView2.Core
{
  [ComVisible(true)]
  public enum CoreWebView2MouseEventKind
  {
    NonClientRightButtonDown = 164, // 0x000000A4
    NonClientRightButtonUp = 165, // 0x000000A5
    Move = 512, // 0x00000200
    LeftButtonDown = 513, // 0x00000201
    LeftButtonUp = 514, // 0x00000202
    LeftButtonDoubleClick = 515, // 0x00000203
    RightButtonDown = 516, // 0x00000204
    RightButtonUp = 517, // 0x00000205
    RightButtonDoubleClick = 518, // 0x00000206
    MiddleButtonDown = 519, // 0x00000207
    MiddleButtonUp = 520, // 0x00000208
    MiddleButtonDoubleClick = 521, // 0x00000209
    Wheel = 522, // 0x0000020A
    XButtonDown = 523, // 0x0000020B
    XButtonUp = 524, // 0x0000020C
    XButtonDoubleClick = 525, // 0x0000020D
    HorizontalWheel = 526, // 0x0000020E
    Leave = 675, // 0x000002A3
  }
}
