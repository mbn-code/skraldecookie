﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Extension]
[assembly: AssemblyTitle("ExamCookie.WinClient")]
[assembly: AssemblyDescription("Examination session logger")]
[assembly: AssemblyCompany("examcookie.dk")]
[assembly: AssemblyProduct("ExamCookie.WinClient")]
[assembly: AssemblyCopyright("Copyright ©  2017 Søren Hyltoft")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("56bc7c39-566d-419f-8a09-e1f4df55be0b")]
[assembly: AssemblyFileVersion("1.4.1.4")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.4.1.4")]
